import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { SignComponent } from './sign/sign.component';
import { UpdateComponent } from './update/update.component';
import { NavComponent } from './nav/nav.component';
import { FoodComponent } from './food/food.component';
import { StudComponent } from './stud/stud.component';
import { UpStudComponent } from './up-stud/up-stud.component';
import { HomeComponent } from './home/home.component';
import { GenComponent } from './gen/gen.component';
import { FormsModule } from '@angular/forms';
import { WorkerComponent } from './worker/worker.component';
import { AttendComponent } from './attend/attend.component';
import { AboutComponent } from './about/about.component';
import { AdminComponent } from './admin/admin.component';
import { RepeatDirective } from './repeat.directive';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    SignComponent,
    UpdateComponent,
    NavComponent,
    FoodComponent,
    StudComponent,
    UpStudComponent,
    HomeComponent,
    GenComponent,
    WorkerComponent,
    AttendComponent,
    AboutComponent,
    AdminComponent,
    RepeatDirective
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
