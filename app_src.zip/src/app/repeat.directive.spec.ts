import { RepeatDirective } from './repeat.directive';

describe('RepeatDirective', () => {
  it('should create an instance', () => {
    const directive = new RepeatDirective();
    expect(directive).toBeTruthy();
  });
});
