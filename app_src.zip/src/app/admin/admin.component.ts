import { Component,OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent  {
public res1:any;
constructor(private http:HttpClient){}
  admin()
  {
    const url = 'http://127.0.0.1:5555/api/admin';
    this.http.get(url).subscribe((data) => {
      this.res1 = data;
console.log(this.res1);

      });
  }
}
