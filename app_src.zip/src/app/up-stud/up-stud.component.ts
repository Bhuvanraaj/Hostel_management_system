import { Component } from '@angular/core';

@Component({
  selector: 'app-up-stud',
  templateUrl: './up-stud.component.html',
  styleUrls: ['./up-stud.component.css']
})
export class UpStudComponent {

}
