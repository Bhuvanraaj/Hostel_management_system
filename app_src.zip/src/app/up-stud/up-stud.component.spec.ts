import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpStudComponent } from './up-stud.component';

describe('UpStudComponent', () => {
  let component: UpStudComponent;
  let fixture: ComponentFixture<UpStudComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpStudComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UpStudComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
