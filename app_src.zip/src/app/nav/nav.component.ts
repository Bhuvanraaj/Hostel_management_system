import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { ShareService } from '../service/share.service'

import { Router } from '@angular/router';
@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.css']
})
export class NavComponent {

  constructor(private http:HttpClient,private router:Router){}

public user:any;
logout(){
console.log("hai");
this.user="logout";
const url5 = 'http://127.0.0.1:5555/api/logout';
  this.http.post(url5,this.user).subscribe((data) => {
    console.log("hai");
if(data=="false"){
  this.router.navigateByUrl('/login');
}
  });
}
}
