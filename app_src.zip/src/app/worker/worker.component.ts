import { HttpClient } from '@angular/common/http';
import { Component,OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import { FormControl, FormGroup } from '@angular/forms'
export class Upd{constructor(public name:string,public id:string,public val:string){}}
export class Stud{
  constructor(
    public id:string,
    public name:string,
    public age:string,
    public nat:string,
    public type:string,
    public mob:string){}
}
export class Stud1{
  constructor(public id:string){}
}
@Component({
  selector: 'app-worker',
  templateUrl: './worker.component.html',
  styleUrls: ['./worker.component.css']
})
export class WorkerComponent implements OnInit {
  public workList:any;
  public user: Stud= new Stud('','','','','','');
  public user2:Stud1=new Stud1('');
  public user3:Upd=new Upd('','','')
  public res1:any;
  constructor(private http:HttpClient){}
  ngOnInit():void
  {
   this.http.get('http://127.0.0.1:5555/api/worker').subscribe(
   Response=>
   {
       if(Response)
        {
          console.log('Data is received from db');
        }
        console.log(Response);
        this.workList=Response;
    })
  }
  add=false;work=true;
  update=false;
  delete=false;
  adding(){
  this.add=true;
  this.update=false;
  this.delete=false;
  this.work=false;
  console.log("add is clicked");
  }
  updating1(){
  this.update=true;
  this.add=false;
  this.delete=false;
  this.work=false;
  console.log("update is clicked");
  }
  deleting(){
  this.delete=true;
  this.add=false;
  this.update=false;
  this.work=false;
  }
  add_val(user:Stud){
    const url5 = 'http://127.0.0.1:5555/api/add_work';
    this.http.post(url5,this.user).subscribe((data) => {

      if(data=="duplicate")
      {
        alert("Already user existed!");
      }
      else if(data=="pass")
      {

        alert("Successfully Added!");
      }
    });


  }
  upd_val(user3:Upd){
    console.log(this.user3);
    const url6 = 'http://127.0.0.1:5555/api/upd_work';
    this.http.post(url6,{yes:user3}).subscribe((data) => {});
    alert("Successfully Updated!");
    }
    stud_del(id1:string)
    {
    console.log(id1);
        const url4 = 'http://127.0.0.1:5555/api/del_work';
        this.http.post(url4,{id:id1}).subscribe((data) => {
          if(data=="Id")
          {
          alert("Id field cannot be null");
          }
          else if(data="Id1")
          {
          alert("deleted");
          }
        });

    }
}
