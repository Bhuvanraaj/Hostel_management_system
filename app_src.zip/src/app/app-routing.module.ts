import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { SignComponent } from './sign/sign.component';
import { UpdateComponent } from './update/update.component';
import { NavComponent } from './nav/nav.component';
import { FoodComponent } from './food/food.component';
import { StudComponent } from './stud/stud.component';
import { HomeComponent } from './home/home.component';
import { GenComponent } from './gen/gen.component';
import { WorkerComponent } from './worker/worker.component';
import { AttendComponent } from './attend/attend.component';
import { AboutComponent } from './about/about.component';
import { AdminComponent } from './admin/admin.component';
const routes: Routes = [
{path:'',component:HomeComponent},
{path:'home',component:HomeComponent},
{path:'sign',component:SignComponent},
{path:'login',component:LoginComponent},
{path:'sign',component:SignComponent},
{path:'update',component:UpdateComponent},
{path:'nav',component:NavComponent},
{path:'food',component:FoodComponent},
{path:'stud',component:StudComponent},
{path:'gen',component:GenComponent},
{path:'worker',component:WorkerComponent},
{path:'attend',component:AttendComponent},
{path:'about',component:AboutComponent},
{path:'admin',component:AdminComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
