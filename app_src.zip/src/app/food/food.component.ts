import { Component,OnInit } from '@angular/core';

import { HttpClient } from '@angular/common/http';
export class Upd{constructor(public name:string,public id:string,public val:string){}}

@Component({
  selector: 'app-food',
  templateUrl: './food.component.html',
  styleUrls: ['./food.component.css']
})
export class FoodComponent {
public foodList:any;
public user3:Upd=new Upd("","","");
constructor(private http:HttpClient){}
ngOnInit():void{
this.http.get('http://127.0.0.1:5555/api/foods').subscribe(
Response=>{
if(Response){
console.log('Data is received from db');
}
console.log(Response);
this.foodList=Response;
}
)
}
update=false;
work=true;
updating1(){
  this.update=true;
  this.work=false;
  console.log("update is clicked");
  }
  upd_val(user3:Upd){
    console.log(this.user3);
    const url6 = 'http://127.0.0.1:5555/api/upd_food';
    this.http.post(url6,{yes:user3}).subscribe((data) => {});

    }
}
