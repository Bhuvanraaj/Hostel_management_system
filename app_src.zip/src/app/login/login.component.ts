import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ShareService } from '../service/share.service'
import { Router } from '@angular/router';
import { fromEvent, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

export class Login{
  constructor(public uname:string,public pass:string){}
}
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  private unsubscriber : Subject<void> = new Subject<void>();

  public user: Login= new Login('','');
  submitted: boolean = false;
  res:any;
  constructor(private http:HttpClient,private router:Router){}

  ngOnInit(): void {
    history.pushState(null, '');
    fromEvent(window, 'popstate').pipe(
      takeUntil(this.unsubscriber)
    ).subscribe((_) => {
      history.pushState(null, '');

    });
  }
  ngOnDestroy(): void {
    this.unsubscriber.next();
    this.unsubscriber.complete();
  }

  public login_up(data:Login){
    this.submitted = true;
    this.user = data;
    console.log(this.user);
    const url = 'http://127.0.0.1:5555/api/login';

    this.http.post(url,this.user).subscribe((data) => {
    this.res = data;
    console.log(data);
    if(this.res.auth=="true" )
    {
    if(this.res.val=="true")
    {
      //FundraiserloginService.setId(this.res.email);
        alert("Successful Login!");
      this.router.navigateByUrl('/admin');
    }
    }
  else{
  alert("Invalid Username or Password!");
  }
    });
}

}
