function disp(a)
{
	var x=document.getElementById("label_day");
	x.textContent=a+" is selected";
}
function disp2(a)
{
	var x=document.getElementById("label_time");
	x.textContent=a+" is selected";
}
function update()
{
	window.alert("submitted successfully");
}
