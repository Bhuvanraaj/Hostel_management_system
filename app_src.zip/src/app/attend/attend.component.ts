import { Component ,OnInit, ɵgetUnknownElementStrictMode} from '@angular/core';
import { HttpClient } from '@angular/common/http';
export class Room{constructor(public room:Number){}}
export class Room2{constructor(public room:string){}}
export class attend{constructor(public id:string){}}
export class Date_class{constructor(public val:string){}}
export class Date_class2{constructor(public val:string){}}
@Component({
  selector: 'app-attend',
  templateUrl: './attend.component.html',
  styleUrls: ['./attend.component.css']
})
export class AttendComponent implements OnInit {
public user:Room=new Room(1);
public user1:Room2=new Room2("");
public user2:attend=new attend("");
public date1:Date_class=new Date_class("");
public date2:Date_class2=new Date_class2("");
public attendList:any;
public List:any;
public Attend:any;
constructor(private http:HttpClient){}
ngOnInit():void{}
put_attend()
{
  const url5 = 'http://127.0.0.1:5555/api/put_attend';
  this.http.post(url5,{no:this.user.room}).subscribe((data) => {
    this.List=data;
  });
}

yes(user2:string)
{
  const url5 = 'http://127.0.0.1:5555/api/present';
console.log(this.date1.val);
  console.log(user2);
  this.http.post(url5,{name:user2,date:this.date1.val}).subscribe((data) => {

   });
}
no(user3:string){
  const url5 = 'http://127.0.0.1:5555/api/absent';
  console.log(user3);
console.log(this.date1.val);
  this.http.post(url5,{name:user3,date:this.date1.val}).subscribe((data) => {});
}
view_attend(){
console.log("hiiiii");
  const url9 = 'http://127.0.0.1:5555/api/find_attend';
  this.http.post(url9,{day:this.date2.val}).subscribe((data) => {
console.log(data);
this.Attend=data;
  });

  // const url5 = 'http://127.0.0.1:5555/api/view_attend';
  // this.http.get(url5).subscribe((response) => {
  // this.attendList=response;
  // console.log(response);
  // this.Attend=response;
  //  });
}

}
