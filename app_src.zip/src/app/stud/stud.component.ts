import { HttpClient } from '@angular/common/http';
import { Component,OnInit } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { FormControl, FormGroup } from '@angular/forms'
import { ShareService } from '../service/share.service'
import { Router } from '@angular/router';
export class Stud{
  constructor(
    public id:string,
    public name:string,
    public adm:string,
    public roll:string,
    public age:string,
    public nat:string,
    public mob:string,
    public room:Number){}
}
export class Upd{constructor(public name:string,public id:string,public val:string){}}
export class Stud1{constructor(public id:string){}}
@Component({
  selector: 'app-stud',
  templateUrl: './stud.component.html',
  styleUrls: ['./stud.component.css']
})
export class StudComponent implements OnInit
 {
      public studList:any;
      public res1:any;
      public user: Stud= new Stud('','','','','','','',0);
      public user2:Stud1=new Stud1("");
      public user3:Upd=new Upd("","","");
      constructor(private http:HttpClient){
      }
      ngOnInit():void
      {
       this.http.get('http://127.0.0.1:5555/api/studs').subscribe(
       Response=>
       {
           if(Response)
            {
              console.log('Data is received from db');
            }
            console.log(Response);
            this.studList=Response;

        })
        const url = 'http://127.0.0.1:5555/api/studs';
        this.http.get(url).subscribe((data) => {
        this.res1 = data;
console.log(this.res1);

        });

      }
add=false;work=true;
update=false;
delete=false;
adding(){
this.add=true;
this.update=false;
this.delete=false;
this.work=false;
console.log("add is clicked");
}
updating1(){
this.update=true;
this.add=false;
this.delete=false;
this.work=false;
console.log("update is clicked");
}
deleting(){
this.delete=true;
this.add=false;
this.update=false;
this.work=false;
}
add_val(user:Stud){
  const url5 = 'http://127.0.0.1:5555/api/add_stud';
  this.http.post(url5,this.user).subscribe((data) => {
console.log(data);
if(data=="duplicate")
{
  alert("Already user existed!");
}
else if(data=="pass")
{
  alert("Successfully Added!");
}
else if(data=="Empty")
{
alert("Don't laeave any field empty!");
}
else
{

  alert("Successfully Added!");
}
  });

}
stud_del(id1:string)
{
console.log(id1);
    const url4 = 'http://127.0.0.1:5555/api/del_stud';
    this.http.post(url4,{id:id1}).subscribe((data) => {
if(data=="Id")
{
alert("Id field cannot be null");
}
else if(data="Id1")
{
alert("deleted");
}
    });

}
upd_val(user3:Upd){
console.log(this.user3);
const url6 = 'http://127.0.0.1:5555/api/upd_stud';
this.http.post(url6,{yes:user3}).subscribe((data) => {});
alert("Successfully updated!");
}
disp(value:string){

}

 }

