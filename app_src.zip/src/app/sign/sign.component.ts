import { Component ,OnInit} from '@angular/core';
import { HttpClient } from '@angular/common/http';
export class Sign{
constructor(public uname:string,public pass:string,public pass2:string){}
}
@Component({
  selector: 'app-sign',
  templateUrl: './sign.component.html',
  styleUrls: ['./sign.component.css']
})
export class SignComponent implements OnInit{
  ngOnInit(): void {
    this.status='waiting';
  }
  public sign:Sign=new Sign('','','');
  public submitted:Boolean = false;
  public res:any;
  public status!:String;
  constructor(private http:HttpClient){}
  sign_up(data:Sign){
    this.sign = data;
    console.log(this.sign);
    const url = 'http://127.0.0.1:5555/api/sign';
if(data.pass==data.pass2)
{
    this.http.post(url,this.sign).subscribe((data) => {
   // this.res=data;
    console.log(this.res);
    if(data=="success")
    {
    alert("successfully created");
    }
    else if(data=="empty")
    {
    alert("Don't leave empty field!");
    }
    else if(data=="duplicate")
    {
    alert("Username already exist!");
    }
    });


}
else
{
alert("CHECK PASSWORD")
}

}
value():void{

}
}
