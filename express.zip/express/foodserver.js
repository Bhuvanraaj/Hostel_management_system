var express = require('express');
const mongoose = require('mongoose');
mongoose.set('strictQuery',false);
const app =express();

mongoose.connect('mongodb://127.0.0.1:27017/Hostel');
var db = mongoose.connection;

db.on('error',console.log.bind(console,"Connection error"));
db.once('open',function(callback){
    console.log("Connected to db");
})
const studSchema=new mongoose.Schema({
    _id:{
         type:String,
        required: true,
        auto:true
    },
    name:{
        type:String,
        required:true
    },
    Adm_no:{
        type:Number,
        required:true
    },
     Roll_no:{
        type:String,
        required:true
    },
     Age:{
        type:Number,
        required:true
    },
     Native:{
        type:String,
        required:true
    },
     Mobile:{
        type:Number,
        required:true
    },
     Att:{
        type:String,
        required:true
    }

})
const foodSchema = new mongoose.Schema({
    _id:{
        type:mongoose.Schema.Types.ObjectId,
        required: true,
        auto:true
    },
    day:{
        type: String,
        required:true
    },
    bre:{
        type:String,
        required:true,
    },
    lun:{
        type:String,
        required:true,
    },
    din:{
        type:String,
        required:true,
    }
});
const food = mongoose.model('Food',foodSchema,'Food');
const stud = mongoose.model('student',studSchema,'student');
food.find().then((foods)=>{
    console.log(foods)
}).catch((error) => {
    console.log(error);
});
stud.find().then((studs)=>{
   // console.log(studs)
}).catch((error) => {
    console.log(error);
});

app.get('/foods', async (req,res)=>{
    res.set({
        'Access-Control-Allow-Origin':'*'
    });
    try{
        const foods = await food.find();
        res.json(foods);
    } catch(err){
        console.error(err);
        res.sendStatus(500);
    }
});

app.get('/studss', async (req,res)=>{
    res.set({
        'Access-Control-Allow-Origin':'*'
    });
    try{
        const studs = await stud.find();
        
        res.json(studs);
    } catch(err){
        console.error(err);
        res.sendStatus(5000);
    }
});
app.post("/delete",function(req,res){
	var del_val=req.body.del;
    console.log(req.body.del);
	//db.collection('student').remove({_id:del_val});
	console.log("removed");
})

app.get('/',function(req,res){
    res.set({
        'Access-Control-Allow-Origin':'*'
    });
}).listen(4000);
console.log("Listening to 4000");
