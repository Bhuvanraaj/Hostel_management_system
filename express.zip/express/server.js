const express = require('express')
const app = express()
const mongoose = require('mongoose');
mongoose.set('strictQuery', false);
var routes = require('./route/routes');
var studentModel = require('./src/student/studentModel');


app.listen(9993,function check(err)
{
    if(err)
    console.log("error")
    else
    console.log("started")
});

// app.post("/sign",function(req,res))
// {
//     var username=req.body.username;
//     var mail=req.body.mail;
//     var pass = req.body.pass;
//     var data={
//         "username":username,
//         "mail":mail,
//         "pass":pass
//     }
// }

mongoose.connect("mongodb://0.0.0.0:27017/core",{useNewUrlParser: true,  useUnifiedTopology: true },
function checkDb(error)
{
    if(error)
    {
        console.log("Error Connecting to DB");
    }
    else
    {
        console.log("successfully Connected to DB");
    }
});

// new studentModel({

//   }).save();

app.use(express.json());
app.use(routes);