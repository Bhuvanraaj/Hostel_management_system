const express = require('express');
var router = express.Router();
const Sign_ = require('../model/admin');
const food_=require('../model/food');
const stud_=require('../model/student');
const work_=require('../model/worker');
const attend_=require('../model/attend');
const mongoose = require('mongoose')
mongoose.connect('mongodb://127.0.0.1:27017/Hostel');
var db=mongoose.connection;
var x=0;
mongoose.set('strictQuery', false);
app=express();
router.get('/admin',async(req,res,next)=>{
	res.set({
		'Access-Control-Allow-Origin':'*'
	});
	try{
		const result = await Sign_.find({});
		res.json(result);
		
	}
	catch(err){
		console.log(err);
		res.sendStatus(500);
	}
});
router.get('/foods', async (req,res)=>{
    res.set({
        'Access-Control-Allow-Origin':'*'
    });
    try{
        const foods = await food_.find();
        res.json(foods);
    } catch(err){
        console.error(err);
        res.sendStatus(500);
    }
});
router.post('/present',async(req,res,next)=>{
	res.set({
		'Access-Control-Allow-Origin':'*'
	});
	try{
		var id=req.body.name;
		var date2=req.body.date;
		
	var sts=await attend_.find({"id":id,"date":date2},{date:1,status:1});
	if(sts[0]==null)
	{
		var data={
			"id":id,
			"date":date2,
			"status":"P"
		}
		db.collection('attend').insertOne(data,function(err, collection){
			if (err) throw err;
			console.log("inserted Successfully");
	
		});
	}
	else if(sts[0].status=="A")
		{
			db.collection('attend').updateOne({"id":id,"date":date2},{$set:{"status":"P"}});
		}
	else{
		console.log("bii");		
		}
	}

	catch(err){
		console.log(err);
		res.sendStatus(500);
	}
});
router.post('/absent',async(req,res,next)=>{
	res.set({
		'Access-Control-Allow-Origin':'*'
	});
	try
	{
		var id=req.body.name;
		var date2=req.body.date;
		console.log(id+" "+date2);
		var sts=await attend_.find({"id":id,"date":date2},{date:1,status:1});
		if(sts[0]==null)
		{
			
			var data={
				"id":id,
				"date":date2,
				"status":"A"
			}
			db.collection('attend').insertOne(data,function(err, collection){
			if (err) throw err;
			console.log("inserted Successfully");
			});
		}
		else if(sts[0].status=="P")
		{
			db.collection('attend').updateOne({"id":id,"date":date2},{$set:{"status":"A"}});
		}
		else{
			console.log(sts[0].status);
			console.log("bii");		
			}
	}
	catch(err){
		console.log(err);
		res.sendStatus(500);
	}
});

router.post('/find_attend', async (req,res)=>{
    res.set({
        'Access-Control-Allow-Origin':'*'
    });
    try{
		var y=req.body.day;
		const attend = await attend_.find({"date":y},{"id":1,"status":1,"date":1});
		res.json(attend);
	    }
	catch(err){
        console.error(err);
        res.sendStatus(500);
    }
});
router.post('/put_attend',async(req,res,next)=>{
	res.set({
		'Access-Control-Allow-Origin':'*'
	});
	try
	{
		var x=req.body.no;
		const result = await stud_.find({"room":x},{_id:1,name:1,Adm_no:1,Roll_no:1,Age:1,Native:1,Mobile:1,room:1});
		res.json(result);
	}
	catch(err){
		console.log(err);
		res.sendStatus(500);
	}
});
router.get('/worker', async (req,res)=>{
    res.set({
        'Access-Control-Allow-Origin':'*'
    });
    try{
        const works = await work_.find();
        res.json(works);
    } catch(err){
        console.error(err);
        res.sendStatus(500);
    }
});
router.get('/studs', async (req,res)=>{
    res.set({
        'Access-Control-Allow-Origin':'*'
    });
    try{
        const studs = await stud_.find();
        
        res.json(studs);
    } catch(err){
        console.error(err);
        res.sendStatus(5000);
    }
});
router.post('/upd_food',async(req,res,next)=>{
	res.set({
		'Access-Control-Allow-Origin':'*'
	});
	try{
		console.log(req.body.yes.inp);
		let x=req.body.yes.select;
		let y=req.body.yes.res;
		console.log(x+y);
		if(x=="bre"){db.collection('Food').updateMany({day:req.body.yes.inp},{$set:{"bre":req.body.yes.res}});}
		if(x=="lun"){db.collection('Food').updateMany({day:req.body.yes.inp},{$set:{"lun":req.body.yes.res}});}
		if(x=="din"){db.collection('Food').updateMany({day:req.body.yes.inp},{$set:{"din":req.body.yes.res}});}
		
	}catch(err){
		console.log(err);
		res.sendStatus(500);
	}
});
router.post('/add_work',async(req,res,next)=>{
	res.set({
		'Access-Control-Allow-Origin':'*'
	});
		
	try{
		var id = req.body.id;
		var name =req.body.name;
		var age = req.body.age;
		var nat = req.body.nat;
		var type=req.body.type;
		var mob = req.body.mob;
		var data={
		"_id": id,
        "name": name,
		"Age":age,
		"Native":nat,
		"type":type,
		"Mobile":mob
		}
		console.log(data);
		const sts=await work_.find({"_id":id},{})
		console.log(sts);
		if(sts[0]==null){
		db.collection('worker').insertOne(data,function(err, collection){
			if (err) throw err;
			res.json("pass");
		});
		}
		else{
			res.json("duplicate");
		}
		
	}catch(err){
		console.log(err);
		res.sendStatus(500);
	}
});
router.post('/upd_work',async(req,res,next)=>{
	res.set({
		'Access-Control-Allow-Origin':'*'
	});
	try{
		console.log(req.body.yes.inp);
		let x=req.body.yes.select;
		let y=req.body.yes.res;
		console.log(x+y);
		if(x=="name"){db.collection('worker').updateMany({_id:req.body.yes.inp},{$set:{"name":req.body.yes.res}});}
		if(x=="Age"){db.collection('worker').updateMany({_id:req.body.yes.inp},{$set:{"Age":req.body.yes.res}});}
		if(x=="Native"){db.collection('worker').updateMany({_id:req.body.yes.inp},{$set:{"Native":req.body.yes.res}});}
		if(x=="type"){db.collection('worker').updateMany({_id:req.body.yes.inp},{$set:{"type":req.body.yes.res}});}
		if(x=="Mobile"){db.collection('worker').updateMany({_id:req.body.yes.inp},{$set:{"Mobile":req.body.yes.res}});}
	}catch(err){
		console.log(err);
		res.sendStatus(500);
	}
});
router.post('/del_work',async(req,res,next)=>{
	res.set({
		'Access-Control-Allow-Origin':'*'
	});
	try{
		console.log(req.body.id.del);
		var x=req.body.id.del;
		if(!x)
		{
			res.json("Id");
			
		}
		else{
			res.json("Id1");
			
		const result = await work_.deleteOne({_id:req.body.id.del});
		}
	}catch(err){
		console.log(err);
		res.sendStatus(500);
	}
});
router.post('/add_stud',async(req,res,next)=>{
	res.set({
		'Access-Control-Allow-Origin':'*'
	});
		
	try{
		var id = req.body.id;
		var name =req.body.name;
		var adm = parseInt(req.body.adm);
		var roll = req.body.roll;
		var age = parseInt(req.body.age);
		var nat = req.body.nat;
		var mob = req.body.mob;
		var room=parseInt(req.body.room);
		var pre="p";
		var data={
		"_id": id,
        "name": name,
		"Adm_no":adm,
		"Roll_no":roll,
		"Age":age,
		"Native":nat,
		"Mobile":mob,
		"room":room
		}
		console.log(data);
		const sts=await stud_.find({"_id":id},{})
		console.log(sts);
		if(sts[0]==null){
		if(id==""|| name==""|| adm==NaN || roll==""|| age==NaN || nat=="" || mob=="" || room==NaN)
		{
			res.json("Empty");
		}
		else{
			db.collection('student').insertOne(data,function(err, collection){
				if (err) throw err;
				res.json("pass");
				});
			
		}
		}
		else{
			res.json("duplicate");
		}
	}
	catch(err){
		console.log(err);
		res.sendStatus(500);
	}
});
router.post('/del_stud',async(req,res,next)=>{
	res.set({
		'Access-Control-Allow-Origin':'*'
	});
	try{
		console.log(req.body.id.del);
		var x=req.body.id.del;
		if(x=="")
		{
			res.json("Id");
		}
		else{
			res.json("Id1");
		const result = await stud_.deleteOne({_id:req.body.id.del});
		}
	}catch(err){
		console.log(err);
		res.sendStatus(500);
	}
});
router.post('/upd_stud',async(req,res,next)=>{
	res.set({
		'Access-Control-Allow-Origin':'*'
	});
	try{
		console.log(req.body.yes.inp);
		let x=req.body.yes.select;
		let y=req.body.yes.res;
		console.log(x+y);
		if(x=="name"){db.collection('student').updateMany({_id:req.body.yes.inp},{$set:{"name":req.body.yes.res}});}
		if(x=="Adm_no"){db.collection('student').updateMany({_id:req.body.yes.inp},{$set:{"Adm_no":req.body.yes.res}});}
		if(x=="Roll_no"){db.collection('student').updateMany({_id:req.body.yes.inp},{$set:{"Roll_no":req.body.yes.res}});}
		if(x=="Age"){db.collection('student').updateMany({_id:req.body.yes.inp},{$set:{"Age":req.body.yes.res}});}
		if(x=="Native"){db.collection('student').updateMany({_id:req.body.yes.inp},{$set:{"Native":req.body.yes.res}});}
		if(x=="Mobile"){db.collection('student').updateMany({_id:req.body.yes.inp},{$set:{"Mobile":req.body.yes.res}});}
		if(x=="room"){
			var z=parseInt(req.body.yes.res);
			db.collection('student').updateMany({_id:req.body.yes.inp},{$set:{"room":z}});
		}
	}catch(err){
		console.log(err);
		res.sendStatus(500);
	}
});

router.post("/sign",  async function(req,res){
	
    res.set({
		'Access-Control-Allow-Origin':'*'
	});
	const dup=await Sign_.find({name:req.body.uname},{});
	console.log(dup)
	
	if(dup=="")
	{
		if(req.body.uname==null || req.body.pass==null || req.body.pass2==null)
		{
		res.json("empty");
		}
		else
		{
		console.log("req received ");
		var name = req.body.uname;
		var pass =req.body.pass;
		var pass2 = req.body.pass2;
        const result = await Sign_.find({},{_id:1}).sort({_id:-1}).limit(1);
        console.log("test="+result+"test="+result[0]);
		var data = {
			"_id": result[0]._id+1,
            "name": name,
			"password":pass,
			"confirm":pass2,
		}
		
		db.collection('logins').insertOne(data,function(err, collection){
		if (err) throw err;
		res.json("success");
		console.log("inserted Successfully");

		});
		}
	}
	else
	{
		res.json("duplicate");
		//console.log(dup); 
	}
});
router.post('/login',async (req,res,next) => {
    res.set({
		'Access-Control-Allow-Origin':'*'
	});
	if(req.body.uname==null || req.body.pass==null){
		res.json({auth:'false'});
	}else{
		try{
			var pass=req.body.pass;
			console.log(req.body.uname);
			console.log(pass);
			const opass = await Sign_.find({name:req.body.uname});
			console.log(opass);
			console.log("opass "+opass[0]);
			console.log(opass[0].password);

			if(!opass || opass[0]==undefined){
			 	res.json({auth:'false'});
				
			 }
			 else if(pass==opass[0].password){
				//res.json({auth:'true',name:req.body.uname,org:opass[0].name,id:opass[0]._id});
				db.collection('valid').updateMany({},{$set:{"val":"true"}});
				var auth1="true";
				var data={auth:auth1,val:"true"};
				res.json(data);
				//res.json({auth:'true'});
			}
			else{
				res.json({auth:'false'});
				
			}
		}catch(err){
			console.log(err);
			res.sendStatus(500);
		}
	}
});
router.post('/logout',async(req,res,next)=>{
	res.set({
		'Access-Control-Allow-Origin':'*'
	});
	try{
		console.log("logout");
		db.collection('valid').updateMany({},{$set:{"val":"false"}});
		res.json("false");
	}catch(err){
		console.log(err);
		res.sendStatus(500);
	}
});

module.exports = router;