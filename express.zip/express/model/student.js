const mongoose = require('mongoose');
const stud=new mongoose.Schema({
    _id:{
         type:String,
        required: true,
        auto:true
    },
    name:{
        type:String,
        required:true
    },
    Adm_no:{
        type:Number,
        required:true
    },
     Roll_no:{
        type:String,
        required:true
    },
     Age:{
        type:Number,
        required:true
    },
     Native:{
        type:String,
        required:true
    },
     Mobile:{
        type:Number,
        required:true
    },
     Att:{
        type:String,
        required:true
    },
    room:{
        type:Number,
        required:true
    }

})
const stud_ = module.exports = mongoose.model('student', stud,'student');