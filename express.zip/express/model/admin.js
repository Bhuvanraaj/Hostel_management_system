const mongoose = require('mongoose');
mongoose.set('strictQuery', false);
const login = mongoose.Schema({
    _id:{
        type:Number,
        required:true
    },
   name:{
        type:String,
        required: true
    },
    password:{
        type:String,
        required: true
    },
   confirm:{
        type:String,
        required: true
    }});
    const Sign_ = module.exports = mongoose.model('logins', login);