const mongoose = require('mongoose');
const stud=new mongoose.Schema({
    _id:{
         type:String,
        required: true,
        auto:true
    },
    name:{
        type:String,
        required:true
    },
   
     Age:{
        type:Number,
        required:true
    },
     Native:{
        type:String,
        required:true
    },
    type:{
        type:String,
        required:true
    },
     Mobile:{
        type:Number,
        required:true
    },
     Att:{
        type:String,
        required:true
    }

})
const stud_ = module.exports = mongoose.model('worker', stud,'worker');