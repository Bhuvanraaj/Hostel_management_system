const mongoose = require('mongoose');
const food = new mongoose.Schema({
    _id:{
        type:mongoose.Schema.Types.ObjectId,
        required: true,
        auto:true
    },
    day:{
        type: String,
        required:true
    },
    bre:{
        type:String,
        required:true,
    },
    lun:{
        type:String,
        required:true,
    },
    din:{
        type:String,
        required:true,
    }
});
const food_ = module.exports = mongoose.model('Food', food,'Food');