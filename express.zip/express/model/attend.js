const mongoose = require('mongoose');
const stud=new mongoose.Schema({
    _id:{
         type:String,
        required: true,
        auto:true
    },
    id:{
            type:String,
            required:true
    },
    date:{
        type:String,
        required:true
    },
    status:{
        type:String,
        required:true
    }
})
const stud_ = module.exports = mongoose.model('attend', stud,'attend');