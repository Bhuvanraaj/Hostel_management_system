var express=require("express");
var bodyParser=require("body-parser");
var router = express.Router();
const mongoose = require('mongoose');
mongoose.set('strictQuery',false);
mongoose.connect('mongodb://127.0.0.1:27017/Hostel');
var db=mongoose.connection;

 
db.on('error', console.log.bind(console, "connection error"));
db.once('open', function(callback){
	console.log("connection succeeded");
})

var app=express()
app.use(bodyParser.json());
app.use(express.static('public'));
app.use(bodyParser.urlencoded({
	extended: true
}));


app.post("/login",function(req,res){

	let uname=req.body.uname;
	console.log(uname);
	let x=db.collection('login').updateMany({name:uname},{$set:{password:uname}});
	console.log(x);
})

app.post("/sign",  function(req,res){
	console.log("req");
	if(req.body.uname==null || req.body.pass==null || req.body.pass2==null){
		res.json({auth:'failed'});
	}
	console.log("req received ");
    res.set({
		'Access-Control-Allow-Origin':'*'
	});
		var name = req.body.uname;
		var pass =req.body.pass;
		var pass2 = req.body.pass2;
		var data = {
			"name": name,
			"password":pass,
			"confirm":pass2,
		}
		console.log(name);
	db.collection('login').insertOne(data,function(err, collection){
		if (err) throw err;
		console.log("inserted Successfully");

	});
});


app.get('/',function(req,res){
res.set({
	'Access-control-Allow-Origin': '*'
	});
return res.redirect('index.html');
}).listen(4000)


console.log("server listening at port 4000");
