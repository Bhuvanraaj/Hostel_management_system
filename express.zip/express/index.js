var express=require("express");
var bodyParser=require("body-parser");
const mongoose = require('mongoose');
var cors = require('cors');

mongoose.connect('mongodb://127.0.0.1:27017/Hostel');
var db=mongoose.connection;mongoose.set('strictQuery', false);
db.on('error', console.log.bind(console, "connection error"));
db.once('connected', ()=>{
	console.log("connection succeeded");
});
const route= require('./route/route');
var app=express();
app.use(cors());
app.use(bodyParser.json());
app.use('/api',route);
app.use(express.static('public'));
app.use(bodyParser.urlencoded({
	extended: true
}));
mongoose.set('strictQuery', false);

app.get('/',function(req,res){
	console.log(req);
	res.set({
		'Access-control-Allow-Origin': '*'
	});
}
);
app.listen(5555,()=>{
	console.log("server listening at port 5555");
});
