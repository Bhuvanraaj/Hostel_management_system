var express=require("express");
var bodyParser=require("body-parser");
const mongoose = require('mongoose');

mongoose.connect('mongodb://127.0.0.1:27017/Hostel');
var db=mongoose.connection;
mongoose.set('strictQuery', false);

db.on('error', console.log.bind(console, "connection error"));
db.once('open', function(callback){
	console.log("connection succeeded");
})

var app=express()
app.use(bodyParser.json());
app.use(express.static('public'));
app.use(bodyParser.urlencoded({
	extended: true
}));

app.post("/login",function(req,res){
	var name=req.body.your_name;
	var pass=req.body.your_pass;
	console.log(name+pass);
})

app.post("/sign",function(req,res){
	var name = req.body.uname;
	var pass = req.body.pass;
    var pass2=req.body.pass2;
	var data = {
		"name": name,
		"password":pass,
        "confirm":pass2
	}
	console.log(name+pass+pass2);
	db.collection('login').insertOne(data,function(err, collection){
		if (err) throw err;
		console.log("Hosteler data inserted Successfully");
			
	});
	//return res.redirect('login.html');
})

app.post("/payment",function(req,res){
	var org_name = req.body.oname;
	var owner_name = req.body.owname;
	var org_email =req.body.oemail;
	var pass = req.body.pass;
	var phone =req.body.mobile_number;
	var reg_no=req.body.reg_number;
	var state=req.body.state;
	var city=req.body.City;
	var street=req.body.street;
	var area=req.body.area;
	console.log(org_name);
	var data = {
		"org_name":org_name,
		"owner_name":owner_name,
		"org_email":org_email,
		"password":pass,
		"phone":phone,
		"reg_no":reg_no,
		"state":state,
		"city":city,
		"street":street,
		"area":area
	}
	db.collection('payment').insertOne(data,function(err, collection){
		if (err) throw err;
		console.log("Fundraiser Record inserted Successfully");
			
	});
	//return res.redirect('signup_success.html');
})

app.get('/',function(req,res){
res.set({
	'Access-control-Allow-Origin': '*'
	});
return res.redirect('index.html');
}).listen(5000)


console.log("server listening at port 5000");
